<?php
/**
 * Created by JetBrains PhpStorm.
 * User: artem
 * Date: 08.05.13
 * Time: 14:19
 * To change this template use File | Settings | File Templates.
 */
?>
<h2>Личное развитие:</h2>


<strong>Статус:</strong> <?=$data->statuspartner;?> <br>

<strong>Уровень в партнерской программе:</strong> <?=$data->partnerlevel?> <br>

<strong>Процент отчислений с взносов сотрудников 2-10 уровней:</strong> <?=$data->bonus_from_other_levels?>% <br>

<!--доступно только Участникам и Партнерам-->
<!--<strong>Уровень в потребительской программе:</strong> --><?//=$status?><!-- <br>-->


<strong>Id спонсора:</strong> <?=$data->parent->id?> <br>
<strong>ФИО спонсора:</strong> <?=$data->parent->fio?> <br>