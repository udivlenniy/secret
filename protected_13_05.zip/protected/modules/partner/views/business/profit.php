<?php
/**
 * Created by JetBrains PhpStorm.
 * User: artem
 * Date: 08.05.13
 * Time: 14:39
 * To change this template use File | Settings | File Templates.
 */
?>
<strong>Партнерская программа</strong> – суммарное  кол-во баллов, заработанное в Партнерской программе (20% с 1 уровня, + отчисления с 2-10 уровней)<br>
<!--<strong>Партнерская программа</strong> – суммарное  кол-во баллов, заработанное в Партнерской программе (20% с 1 уровня, + отчисления с 2-10 уровней)<br>-->