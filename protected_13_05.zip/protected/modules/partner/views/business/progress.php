<?php
/**
 * Created by JetBrains PhpStorm.
 * User: artem
 * Date: 08.05.13
 * Time: 14:33
 * To change this template use File | Settings | File Templates.
 */
?>
<!--<strong>Кол-во занятых* сотрудников:</strong>--><?//=$data->childCountPartner?><!-- <br>-->
<div id="counters">
    <strong>Кол-во сотрудников всего(участников и партнёров всего):</strong>
    <?
        echo ($childCountMember+$childCountPartner);
        if(($childCountMember+$childCountPartner)>0){ echo $data->ajaxlink('Подробнее','/controller/ACTION', array('type'=>'all')); }
    ?> <br>
    <strong>Кол-во сотрудников в статусе Участник:</strong>
    <?
        echo $childCountMember;
        if($childCountMember>0){ echo $data->ajaxlink('Подробнее','/controller/ACTION', array('type'=>Partner::STATUS_MEMBER)); }
    ?> <br>
    <strong>Кол-во сотрудников в статусе Партнер:</strong>
    <?
        echo $childCountPartner;

        if($childCountPartner>0){ echo $data->ajaxlink('Подробнее','/controller/ACTION', array('type'=>Partner::STATUS_Partner)); }

    ?> <br>
    <strong>Кол-во «Партнеров» на 1 уровне:</strong>
    <?
        echo $childCountPartnerLevel1;
        if($childCountPartnerLevel1>0){ echo $data->ajaxlink('Подробнее','/controller/ACTION', array('type'=>'partner_level1')); }
    ?>
</div>
<!--после клика на детальный просмотр отображаем таблицу с пагинацией, спрятав перед этим данные счётчиков-->
<div id="tbl">

</div>