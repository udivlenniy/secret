<?php
/**
 * Created by JetBrains PhpStorm.
 * User: artem
 * Date: 07.05.13
 * Time: 18:27
 * To change this template use File | Settings | File Templates.
 */
class BusinessController extends BaseUserController{

    /**
     * @var string name of the model class.
     */
    public $modelName = 'Partner';

    /**
     * @var string name of the method of model class that returns data.
     */
    public $methodName='fillTree';

    public $parent_id = 'parent_id';
    public $label = 'fio';

    /**
     * @var int id of the node that is taken as root node.
     */
    public $rootId=null;
    /**
     * @var bool wether the root node should be displayed.
     */
    public $showRoot=true;

    public function actions(){
        return array(
            'fillTree'=>array(
                'class'=>'ext.actions.XFillTreeAction',
                'modelName'=>'Partner',
                'parent_id'=>'root',
                'label'=>'fio',
                'showRoot'=>false
            )
        );
    }


    public function actionIndex()
    {

        //$model = Partner::model()->findByPK(1); // Здесь вместо Categories меняем на свою модель
        //$tree = $model->descendants()->findAll();
        //var_dump()
        //$this->render('structure',array('tree'=>$tree,));



        //$this->render('structure',array(
            //'treedata'=>Partner::model()->treedata(Yii::app()->user->id),
        //));

        $this->render('index');
    }

    /*
     * личное развитие бизнесса
     */
    public function actionPersonal(){

        if(!Yii::app()->request->isAjaxRequest){
            throw new CHttpException(400,'Invalid request');
        }

        //формируем массив с данными для отображения в форме для юзера
        $data = Partner::model()->findByPk(Yii::app()->user->id);

        $this->renderPartial('personal',array(
            'data'=>$data,
        ));
    }

    /*
     * развитие бизнесса
     */
    public function actionProgress(){

        if(!Yii::app()->request->isAjaxRequest){
            //throw new CHttpException(400,'Invalid request');
        }

        //формируем массив с данными для отображения в форме для юзера
        $data = Partner::model()->findByPk(Yii::app()->user->id);

        $this->renderPartial('progress',array(
            'data'=>$data,
            'childCountMember'=>$data->countChildren(Partner::STATUS_MEMBER),
            'childCountPartner'=>$data->countChildren(Partner::STATUS_Partner),
            'childCountPartnerLevel1'=>$data->countChildren(Partner::STATUS_Partner, 1),
        ));
    }

    /*
     * доход пользователя от партнёрской программы+потребительской программы
     */
    public function actionProfit(){
        if(!Yii::app()->request->isAjaxRequest){
            throw new CHttpException(400,'Invalid request');
        }
        $this->renderPartial('profit');
    }

    /*
     * дерево структуры пользователей ,вся структура рефералов и партнёров
     */
//    public function actionStructure(){
//        if(!Yii::app()->request->isAjaxRequest){
//            throw new CHttpException(400,'Invalid request');
//        }
//
//        $this->renderPartial('structure', false, true);
//    }

    public function actionTree(){

        if(!Yii::app()->request->isAjaxRequest){
            throw new CHttpException(400,'Invalid request');
        }

        if(!isset($_GET['root'])||$_GET['root']=='source'){
            $rootId=Yii::app()->user->id;
            $showRoot=true;
        }else{
            $rootId=$_GET['root'];
            $showRoot=false;
        }

        $partners = Partner::model()->treedata($rootId, $showRoot);

        echo CTreeView::saveDataAsJson($partners);
    }

    /**
     * @return CActiveRecord
     */
    protected function getModel()
    {
        return CActiveRecord::model($this->modelName);
    }
}