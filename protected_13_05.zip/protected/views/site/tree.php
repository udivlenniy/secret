<?php
/**
 * Created by JetBrains PhpStorm.
 * User: artem
 * Date: 07.05.13
 * Time: 16:24
 * To change this template use File | Settings | File Templates.
 */
$this->widget(
    'CTreeView',
    array('url' => array('ajaxFillTree'))
);
